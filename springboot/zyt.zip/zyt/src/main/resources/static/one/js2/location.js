function Location() {
    this.items = {
        '0': {1: '第一产业', 2: '第二产业', 3: '第三产业'},
        '0,1': {1: '农、林、牧、渔业'},
        '0,1,1': {1: '农业', 2: '林业', 3: '畜牧业', 4: '渔业'},
        '0,2': {1: '采矿业', 2: '制造业', 3: '电力、热力、燃气及水生产和供应业', 4: '建筑业'},
        '0,2,1': {1: '煤炭开采和洗选业', 2: '石油和天然气开采业', 3: '其他采矿业'},
        '0,2,2': {1: '农副食品加工业', 2: '计算机、通信和其他电子设备制造业', 3: '其他制造业'},
        '0,2,3': {1: '电力、热力生产和供应业', 2: '燃气生产和供应业', 3: '水的生产和供应业'},
        '0,2,4': {1: '房屋建筑业', 2: '土木工程建筑业', 3: '建筑安装业', 4: '建筑装饰和其他建筑业'},
        '0,3': {1: '批发和零售业', 2: '交通运输、仓储和邮政业', 3: '住宿和餐饮业', 4: '信息传输、软件和信息技术服务业'},
        '0,3,1': {1: '批发业', 2: '零售业'},
        '0,3,2': {1: '铁路运输业', 2: '道路运输业', 3: '水上运输业', 4: '仓储业', 5: '邮政业'},
        '0,3,3': {1: '住宿业', 2: '餐饮业'},
        '0,3,4': {1: '电信、广播电视和卫星传输服务', 2: '互联网和相关服务', 3: '软件和信息技术服务业'},
    };
}

Location.prototype.find = function (id) {
    if (typeof(this.items[id]) == "undefined")
        return false;
    return this.items[id];
}

Location.prototype.fillOption = function (el_id, loc_id, selected_id) {
    var el = $('#' + el_id);
    var json = this.find(loc_id);
    if (json) {
        var index = 1;
        var selected_index = 0;
        $.each(json, function (k, v) {
            var option = '<option value="' + k + '">' + v + '</option>';
            el.append(option);

            if (k == selected_id) {
                selected_index = index;
            }

            index++;
        })
        //el.attr('selectedIndex' , selected_index); 
    }
    el.select2("val", "");
}

