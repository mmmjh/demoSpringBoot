package edu.zyt.mapper;

import edu.zyt.model.CollegeInfo;

import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CollegeInfoMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(CollegeInfo record);

    int insertSelective(CollegeInfo record);


    CollegeInfo selectByPrimaryKey(Integer id);

    List<CollegeInfo> getall();

    int updateByPrimaryKeySelective(CollegeInfo record);

    int updateByPrimaryKey(CollegeInfo record);
}