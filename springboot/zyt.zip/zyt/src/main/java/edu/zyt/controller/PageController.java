package edu.zyt.controller;

import edu.zyt.model.CollegeInfo;
import edu.zyt.model.Equipment;

import edu.zyt.service.CollegeService;
import edu.zyt.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


/**
 * html页面转发
 */
@Controller
@RequestMapping(value = {"/page"})
public class PageController {
    @Autowired
    private CollegeService collegeService;
    @Autowired
    private EquipmentService equipmentService;


    @RequestMapping(value = {"/"})
    public String sh() {
        return "sh";
    }

    @RequestMapping(value = {"index"})
    public String index() {
        return "index";
    }

    @RequestMapping(value = {"add"})
    public String add() {
        return "add";
    }


    @RequestMapping(value = {"home"})
    public String home() {
        return "home";
    }

    @RequestMapping(value = {"login"})
    public String login() {
        return "login";
    }

    @RequestMapping(value = {"showall"})
    public ModelAndView showall() {
        List<Equipment> equipments = equipmentService.getall();

        ModelAndView ma = new ModelAndView();
        ma.addObject("equipments", equipments);
        ma.setViewName("select/showall");
        return ma;
    }

    @RequestMapping(value = {"showcollege"})
    public ModelAndView showcollege() {
        List<CollegeInfo> collegeInfos = collegeService.getall();

        ModelAndView ma = new ModelAndView();
        ma.addObject("collegeInfos", collegeInfos);
        ma.setViewName("select/showall");
        return ma;
    }

    /***
     * 信息添加跳转页面
     * @return
     */

    @RequestMapping(value = {"addpage"})
    public String addpage() {

        return "addpage";
    }

    /***
     * 文件上传跳转页面
     * @return
     */

    @RequestMapping(value = {"uploadpage"})
    public String uploadpage() {

        return "uploadpage";
    }

    /***
     * 信息添加方法
     * @return
     */

    @RequestMapping(value = {"addxinxi"})
    public String addxinxi(Equipment equipment) {
        System.out.println("时间参数" + equipment.getTime());
        int num = equipmentService.addpage(equipment);

        return "index";
    }

    /***
     * 信息删除的方法
     * @return
     */

    @RequestMapping(value = {"deletexinxi"})
    public String deletexinxi(Equipment equipment) {

        System.out.println("你要删除的信息id");
        equipmentService.deleteByPrimaryKey(equipment.getId());

        return "index";
    }

    /***
     * 信息更新的方法
     * @return
     */

    @RequestMapping(value = {"updatexinxi"})
    public String updatexinxi(Equipment equipment) {
        System.out.println("控制器接受参数为" + equipment.getTime());

        equipmentService.updatepage(equipment);

        return "index";
    }

    /***
     * 信息删除页面
     * @return
     */

    @RequestMapping(value = {"deletepage"})
    public String deletepage() {

        return "deletepage";
    }

    /***
     * 信息更新页面跳转控制
     * @return
     */

    @RequestMapping(value = {"updatepage"})
    public String updatepage() {

        return "updatepage";
    }

    @RequestMapping(value = {"select"})
    public ModelAndView select() {
        List<Equipment> equipments = equipmentService.getall();
        for (int i = 0; i < equipments.size(); i++) {
            System.out.println(equipments.get(i).getId());
        }
        ModelAndView ma = new ModelAndView();
        ma.addObject("equipments", equipments);
        //ma.getModel().put("t", "wys");
        ma.setViewName("select");

        return ma;

    }


}
