package edu.zyt.service;

import edu.zyt.model.Equipment;

import java.util.List;

public interface EquipmentService {
    List<Equipment> getall();

    int addpage(Equipment equipment);

    int deleteByPrimaryKey(Integer id);

    int updatepage(Equipment equipment);

}
