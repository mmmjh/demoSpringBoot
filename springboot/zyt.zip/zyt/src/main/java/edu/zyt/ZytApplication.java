package edu.zyt;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"edu.zyt.*"})
@MapperScan("edu.zyt.mapper")
public class ZytApplication {

    public static void main(String[] args) {
        SpringApplication.run(ZytApplication.class, args);
    }

}
