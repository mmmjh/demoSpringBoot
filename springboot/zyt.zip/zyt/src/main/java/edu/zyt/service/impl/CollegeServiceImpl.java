package edu.zyt.service.impl;

import edu.zyt.mapper.CollegeInfoMapper;
import edu.zyt.model.CollegeInfo;
import edu.zyt.service.CollegeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@SuppressWarnings("ALL")
@Service("CollegeService")
public class CollegeServiceImpl implements CollegeService {

    @Autowired
    public CollegeInfoMapper collegeInfoMapper;


    @Override
    public List<CollegeInfo> getall() {

        return collegeInfoMapper.getall();//service层调用Mapper中的方法
    }


    @Override
    public int addpage(CollegeInfo equipment) {
        return collegeInfoMapper.insert(equipment);//添加信息的方法

    }


    @Override
    public int deleteByPrimaryKey(Integer id) {
        return collegeInfoMapper.deleteByPrimaryKey(id);
    }


    @Override
    public int updatepage(CollegeInfo collegeInfo) {
        return collegeInfoMapper.updateByPrimaryKey(collegeInfo);
    }

}
