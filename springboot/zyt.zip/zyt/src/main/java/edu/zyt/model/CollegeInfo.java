package edu.zyt.model;

public class CollegeInfo {
    private Integer id;

    private String name;

    private String logo;

    private String province;

    private String level;

    private String type;

    private String zhishu;

    private String is211;

    private String is985;

    private String tel;

    private String address;

    private String email;

    private String url;

    private String remark;

    private String seq;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo == null ? null : logo.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level == null ? null : level.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getZhishu() {
        return zhishu;
    }

    public void setZhishu(String zhishu) {
        this.zhishu = zhishu == null ? null : zhishu.trim();
    }

    public String getIs211() {
        return is211;
    }

    public void setIs211(String is211) {
        this.is211 = is211 == null ? null : is211.trim();
    }

    public String getIs985() {
        return is985;
    }

    public void setIs985(String is985) {
        this.is985 = is985 == null ? null : is985.trim();
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel == null ? null : tel.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq == null ? null : seq.trim();
    }
}