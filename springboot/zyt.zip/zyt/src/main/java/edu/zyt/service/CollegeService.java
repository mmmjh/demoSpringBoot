package edu.zyt.service;

import edu.zyt.model.CollegeInfo;

import java.util.List;

public interface CollegeService {


    List<CollegeInfo> getall();

    int addpage(CollegeInfo collegeInfo);

    int deleteByPrimaryKey(Integer id);

    int updatepage(CollegeInfo collegeInfo);

}
