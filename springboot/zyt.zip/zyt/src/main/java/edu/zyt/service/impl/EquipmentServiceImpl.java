package edu.zyt.service.impl;

import edu.zyt.mapper.EquipmentMapper;
import edu.zyt.model.Equipment;
import edu.zyt.service.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@SuppressWarnings("ALL")
@Service("EquipmentService")
public class EquipmentServiceImpl implements EquipmentService {

    @Autowired
    public EquipmentMapper equipmentMapper;

    @Override
    public List<Equipment> getall() {

        return equipmentMapper.getall();//service层调用Mapper中的方法
    }


    @Override
    public int addpage(Equipment equipment) {
        return equipmentMapper.insert(equipment);//添加信息的方法

    }


    @Override
    public int deleteByPrimaryKey(Integer id) {
        return equipmentMapper.deleteByPrimaryKey(id);
    }


    @Override
    public int updatepage(Equipment equipment) {
        return equipmentMapper.updateByPrimaryKey(equipment);
    }

}
